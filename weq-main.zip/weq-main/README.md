# Web

[![Netlify Status](https://api.netlify.com/api/v1/badges/b4f1c45d-7302-4fdb-8a7a-748e54df4b13/deploy-status)](https://app.netlify.com/sites/antoniopg/deploys)

En este repositorio puedes encontrar todo el código fuente de mi página web.

**Web**: [Antonio Payá](http://www.antoniopg.tk)

## Herramientas:

- <a href="http://getbootstrap.com/" target="_blank">Bootstrap</a>
- <a href="https://fortawesome.github.io/Font-Awesome/" target="_blank">Font Awesome</a>
- <a href="https://daneden.github.io/animate.css/" target="_blank">Animate.css</a>
- <a href="http://dimsemenov.com/plugins/magnific-popup/" target="_blank">Magnific Popup</a>
- <a href="https://github.com/protonet/jquery.inview" target="_blank">Inview JS</a>
- <a href="http://vestride.github.io/Shuffle/" target="_blank">Shuffle</a>
