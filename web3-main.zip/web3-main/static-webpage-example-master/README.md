Simple Static Webpage Example
=============================

> This repo is used as an example on how to get a Static Webpage Published with IPFS and ipscend

## Credits

The page theme was built with Bootstrap by [**David Miller**](https://github.com/davidtmiller), thank you for making it a putting it available.
